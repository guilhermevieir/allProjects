package pt.ipbeja.po2.sokoban2023.images;

public enum ImageType { KEEPER, BOX, BOXEND, WALL, END, FREE }


