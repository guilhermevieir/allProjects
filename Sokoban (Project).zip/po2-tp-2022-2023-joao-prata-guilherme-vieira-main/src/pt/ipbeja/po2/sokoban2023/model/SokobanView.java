package pt.ipbeja.po2.sokoban2023.model;

/**
 * Messages from the model to the interface
 * The user interface code must implement this interface
 * @author anonymized
 * @version 2022/10/13
 */
public interface SokobanView
{
   void update(MessageToUI messageToUI);
}



