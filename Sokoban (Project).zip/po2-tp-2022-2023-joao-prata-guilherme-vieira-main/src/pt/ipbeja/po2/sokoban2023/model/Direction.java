package pt.ipbeja.po2.sokoban2023.model;

/**
 * Direction of movement
 * @author anonymized
 * @version 2022/10/13
 */
public enum Direction {LEFT, RIGHT, UP, DOWN}

