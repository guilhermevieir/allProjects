use GestaoProjetos

-- Inser��o de registros na tabela Projetos
INSERT INTO Projetos (ID_Projeto, Nome_Projeto)
VALUES (1, 'Projeto A'),
       (2, 'Projeto B'),
	   (3, 'Projeto C'),
       (4, 'Projeto D');


-- Inser��o de registros na tabela Parceiros
INSERT INTO Parceiros (ID_Parceiros, ID_Projeto, Nome, Tipo_Parceiro)
VALUES (1, 1, 'Parceiro 1', 'Internacional'),
       (2, 1, 'Parceiro 2', 'Internacional'),
       (3, 2, 'Parceiro 3', 'Internacional'),
	   (4, 3, 'Parceiro 4', 'Internacional'),
       (5, 3, 'Parceiro 5', 'Nacional'),
       (6, 4, 'Parceiro 6', 'Nacional'),
       (7, 3, 'Parceiro 7', 'Internacional'),
       (8, 4, 'Parceiro 8', 'Internacional'),
       (9, 4, 'Parceiro 9', 'Nacional');

-- Inser��o de registros na tabela Tarefas
INSERT INTO Tarefas (ID_Tarefa, ID_Projeto, Nome_Tarefa, Data_Inicio, Data_Termino)
VALUES (1, 1, 'Tarefa 1', '2023-01-01', '2023-01-15'),
       (2, 1, 'Tarefa 2', '2023-01-16', '2023-01-31'),
       (3, 2, 'Tarefa 3', '2023-02-01', '2023-02-28'),
	   (4, 3, 'Tarefa 4', '2023-03-01', '2023-03-15'),
       (5, 3, 'Tarefa 5', '2023-03-16', '2023-03-31'),
       (6, 4, 'Tarefa 6', '2023-04-01', '2023-04-30'),
       (7, 3, 'Tarefa 7', '2023-04-10', '2023-04-20'),
       (8, 4, 'Tarefa 8', '2023-05-01', '2023-05-15');

-- Inser��o de registros na tabela Subtarefas
INSERT INTO Subtarefas (ID_Subtarefa, ID_Tarefa, Nome_Subtarefa)
VALUES (1, 1, 'Subtarefa 1'),
       (2, 1, 'Subtarefa 2'),
       (3, 2, 'Subtarefa 3'),
	   (4, 4, 'Subtarefa 4'),
       (5, 4, 'Subtarefa 5'),
       (6, 5, 'Subtarefa 6'),
       (7, 6, 'Subtarefa 7'),
       (8, 6, 'Subtarefa 8');


-- Inser��o de registros na tabela Pessoas
INSERT INTO Pessoas (ID_Pessoa, ID_Projeto, Nome_Pessoa)
VALUES (1, 1, 'Jo�o'),
       (2, 1, 'Rute'),
       (3, 2, 'Artur'),
	   (4, 3, '�F�bio'),
       (5, 3, 'Prata'),
       (6, 4, 'Silva'),
       (7, 4, 'Ribeiro'),
       (8, 3, 'Guilha');

-- Inser��o de registros na tabela Coordenadores
INSERT INTO Coordenadores (ID_Pessoa, ID_Projeto)
VALUES (1, 1),
       (2, 2),
	   (4, 3),
       (6, 4);

-- Inser��o de registros na tabela Reunioes
INSERT INTO Reunioes (ID_Reuniao, ID_Projeto, Data_Reuniao)
VALUES (1, 1, '2023-01-10'),
       (2, 1, '2023-01-20'),
       (3, 2, '2023-02-15'),
	   (4, 3, '2023-03-10'),
       (5, 4, '2023-04-05');


-- Inser��o de registros na tabela Deliverables
INSERT INTO Deliverables (ID_Deliverable, ID_Tarefa, Tipo_Deliverable)
VALUES (1, 1, 'Documento'),
       (2, 2, 'V�deo'),
       (3, 3, 'Software'),
	   (4, 4, 'Documento'),
       (5, 4, 'V�deo'),
       (6, 5, 'Documento'),
       (7, 6, 'Software'),
       (8, 7, 'V�deo');

-- Inser��o de registros na tabela Documentos
INSERT INTO Documentos (ID_Documento, ID_Deliverable, Numero_Paginas, Formato_Armazenamento)
VALUES (1, 1, 10, 'PDF'),
       (2, 1, 5, 'Word'),
       (3, 2, 20, 'PDF'),
	   (4, 4, 10, 'PDF'),
       (5, 6, 20, 'Word'),
       (6, 7, 5, 'PDF');


-- Inser��o de registros na tabela Videos
INSERT INTO Videos (ID_Video, ID_Deliverable, Formato_Armazenamento, Duracao)
VALUES (1, 2, 'AVI', '00:15:30'),
       (2, 2, 'MP4', '00:10:45'),
       (3, 3, 'MOV', '00:30:00'),
	   (4, 5, 'MP4', '00:30:00'),
       (5, 8, 'AVI', '00:35:32');

-- Inser��o de registros na tabela Softwares
INSERT INTO Softwares (ID_Software, ID_Deliverable, Linguagem_Desenvolvimento, Sistema_Operativo, Manual_Utilizador)
VALUES (1, 3, 'Java', 'Windows', 'Sim'),
       (2, 3, 'Python', 'Linux', 'N�o'),
	   (3, 7, 'Java', 'Windows', 'Sim'),
       (4, 8, 'C#', 'Windows', 'N�o');

-- Inser��o de registros na tabela Deslocacoes
INSERT INTO Deslocacoes (ID_Deslocacao, ID_Projeto, ID_Pessoa, Data_Deslocacao, Descricao)
VALUES (1, 1, 1,'2023-01-05', 'Braga'),
       (2, 1, 2,'2023-01-05', 'Portim�o'),
       (3, 2, 3,'2023-02-20', 'Lisboa');

-- Inser��o de registros na tabela Deslocacoes
INSERT INTO Deslocacoes (ID_Deslocacao, ID_Projeto, ID_Pessoa, ID_Reuniao, Data_Deslocacao, Descricao)
VALUES (2, 3, 4, 2, '2023-03-05', 'Deslocacao para reuni�o'),
       (3, 3, 5, 2, '2023-03-05', 'Deslocacao para reuni�o'),
       (4, 3, 6, 3, '2023-04-01', 'Deslocacao para reuni�o'),
       (5, 4, 7, 3, '2023-04-01', 'Deslocacao para reuni�o'),
       (6, 4, 8, 3, '2023-04-01', 'Deslocacao para reuni�o');