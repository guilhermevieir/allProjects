--Create Database GestaoProjetos

use GestaoProjetos

CREATE TABLE Projetos (
  ID_Projeto INT PRIMARY KEY,
  Nome_Projeto VARCHAR(255),
  Estado VARCHAR(255)
);

CREATE TABLE Parceiros (
  ID_Parceiros INT PRIMARY KEY,
  ID_Projeto INT,
  Nome VARCHAR(255),
  Tipo_Parceiro VARCHAR(255),
  FOREIGN KEY (ID_Projeto) REFERENCES Projetos (ID_Projeto)
);

CREATE TABLE Tarefas (
  ID_Tarefa INT PRIMARY KEY,
  ID_Projeto INT,
  Nome_Tarefa VARCHAR(255),
  Data_Inicio DATE,
  Data_Termino DATE,
  FOREIGN KEY (ID_Projeto) REFERENCES Projetos (ID_Projeto)
);

CREATE TABLE Subtarefas (
  ID_Subtarefa INT PRIMARY KEY,
  ID_Tarefa INT,
  Nome_Subtarefa VARCHAR(255),
  FOREIGN KEY (ID_Tarefa) REFERENCES Tarefas (ID_Tarefa)
);

CREATE TABLE Pessoas (
  ID_Pessoa INT PRIMARY KEY,
  ID_Projeto INT,
  Nome_Pessoa VARCHAR(255),
  FOREIGN KEY (ID_Projeto) REFERENCES Projetos (ID_Projeto)
);

CREATE TABLE Coordenadores (
  ID_Pessoa INT,
  ID_Projeto INT,
  FOREIGN KEY (ID_Pessoa) REFERENCES Pessoas (ID_Pessoa),
  FOREIGN KEY (ID_Projeto) REFERENCES Projetos (ID_Projeto)
);

CREATE TABLE Reunioes (
  ID_Reuniao INT PRIMARY KEY,
  ID_Projeto INT,
  Data_Reuniao DATE,
  FOREIGN KEY (ID_Projeto) REFERENCES Projetos (ID_Projeto)
);

CREATE TABLE Deliverables (
  ID_Deliverable INT PRIMARY KEY,
  ID_Tarefa INT,
  Tipo_Deliverable VARCHAR(255),
  FOREIGN KEY (ID_Tarefa) REFERENCES Tarefas (ID_Tarefa)
);

CREATE TABLE Documentos (
  ID_Documento INT PRIMARY KEY,
  ID_Deliverable INT,
  Numero_Paginas INT,
  Formato_Armazenamento VARCHAR(255),
  FOREIGN KEY (ID_Deliverable) REFERENCES Deliverables (ID_Deliverable)
);

CREATE TABLE Videos (
  ID_Video INT PRIMARY KEY,
  ID_Deliverable INT,
  Formato_Armazenamento VARCHAR(255),
  Duracao TIME,
  FOREIGN KEY (ID_Deliverable) REFERENCES Deliverables (ID_Deliverable)
);

CREATE TABLE Softwares (
  ID_Software INT PRIMARY KEY,
  ID_Deliverable INT,
  Linguagem_Desenvolvimento VARCHAR(255),
  Sistema_Operativo VARCHAR(255),
  Manual_Utilizador VARCHAR(255),
  FOREIGN KEY (ID_Deliverable) REFERENCES Deliverables (ID_Deliverable)
);

CREATE TABLE Deslocacoes (
  ID_Deslocacao INT PRIMARY KEY,
  ID_Projeto INT,
  ID_Pessoa INT,
  ID_Reuniao INT,
  Data_Deslocacao DATE,
  Descricao VARCHAR(255),
  FOREIGN KEY (ID_Projeto) REFERENCES Projetos (ID_Projeto),
  FOREIGN KEY (ID_Pessoa) REFERENCES Pessoas (ID_Pessoa),
  FOREIGN KEY (ID_Reuniao) REFERENCES Reunioes (ID_Reuniao)
);