use GestaoProjetos
-- Selects subentendidos

--Quais s�o os projetos em andamento?
SELECT *
FROM Projetos
WHERE Estado = 'Em andamento';

--Quais s�o as tarefas e subtarefas de um determinado projeto?
SELECT *
FROM Tarefas
WHERE ID_Projeto = 3;

--Quais s�o as datas previstas de in�cio e t�rmino de uma determinada tarefa?
SELECT Data_Inicio, Data_Termino
FROM Tarefas
WHERE ID_Tarefa = 1;

--Quais s�o as pessoas envolvidas em um determinado projeto?
SELECT P.*
FROM Pessoas P
WHERE P.ID_Projeto = 2;

--Quais s�o as reuni�es de parceria registradas?
SELECT R.*, P.Nome AS Nome_Parceiro
FROM Reunioes R
INNER JOIN Parceiros P ON R.ID_Projeto = P.ID_Projeto

--Quais s�o as desloca��es registradas para clientes?
SELECT *
FROM Deslocacoes
WHERE Descricao = 'Cliente';

--Quais s�o os tipos de deliverables associados a uma tarefa?
SELECT DISTINCT D.Tipo_Deliverable
FROM Deliverables D
WHERE D.ID_Tarefa = 2;



-- Selects pedidos

--Quais os projetos que tem maior n�mero de desloca��es? 2. Quais os projetos que tem um maior n�mero de pessoas?
SELECT P.Nome_Projeto, COUNT(D.ID_Deslocacao) AS Num_Deslocacoes
FROM Projetos P
INNER JOIN Deslocacoes D ON P.ID_Projeto = D.ID_Projeto
GROUP BY P.Nome_Projeto
ORDER BY Num_Deslocacoes DESC;

--Quais os projetos que t�m o maior n�mero de pessoas?
SELECT P.Nome_Projeto, COUNT(Pe.ID_Pessoa) AS Num_Pessoas
FROM Projetos P
INNER JOIN Pessoas Pe ON P.ID_Projeto = Pe.ID_Projeto
GROUP BY P.Nome_Projeto
ORDER BY Num_Pessoas DESC;

--Que subtarefas tem um determinado projeto.
SELECT T.Nome_Tarefa, S.Nome_Subtarefa
FROM Tarefas T
INNER JOIN Subtarefas S ON T.ID_Tarefa = S.ID_Tarefa
WHERE T.ID_Projeto = [ID_Projeto];

--Quais os projetos que tem parceiros em comum?
SELECT p1.ID_Projeto, p1.Nome_Projeto, p2.ID_Projeto, p2.Nome_Projeto
FROM Projetos p1
INNER JOIN Parceiros pa1 ON p1.ID_Projeto = pa1.ID_Projeto
INNER JOIN Parceiros pa2 ON pa1.ID_Parceiros <> pa2.ID_Parceiros AND pa1.ID_Projeto <> pa2.ID_Projeto
INNER JOIN Projetos p2 ON pa2.ID_Projeto = p2.ID_Projeto
GROUP BY p1.ID_Projeto, p1.Nome_Projeto, p2.ID_Projeto, p2.Nome_Projeto
ORDER BY p1.ID_Projeto;

--Quais os projetos que tem mais parceiros internacionais?
SELECT P.Nome_Projeto, COUNT(Pa.ID_Parceiros) AS Num_Parceiros_Internacionais
FROM Projetos P
INNER JOIN Parceiros Pa ON P.ID_Projeto = Pa.ID_Projeto
WHERE Pa.Tipo_Parceiro = 'Internacional'
GROUP BY P.Nome_Projeto
ORDER BY Num_Parceiros_Internacionais DESC;