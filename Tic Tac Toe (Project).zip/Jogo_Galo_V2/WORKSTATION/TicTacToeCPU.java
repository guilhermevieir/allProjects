package WORKSTATION;
import javafx.application.*;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.text.FontWeight;
import javafx.scene.layout.Background;
import java.util.Random;
import javafx.scene.layout.BackgroundFill;

public class TicTacToeCPU extends Application {
        private final int BOARD_SIZE = 3;
        private boolean player1Turn;
        private Button[][] buttons;
        private Label playerLabel;
        private int jogadas = 1;
        Random random = new Random();
        private Players p1;
        private boolean gameOver;
        private Button restartButton;
        
        public static void main(String[] args) {
            launch(args);
        }
        @Override
        public void start(Stage primaryStage) {
            primaryStage.setOnCloseRequest(e -> Platform.runLater(() -> {
                Platform.exit();
                System.exit(0);
            }));
            // Criação de um panel grid
            GridPane grid = new GridPane();
            buttons = new Button[BOARD_SIZE][BOARD_SIZE];
            gameOver = false;

            // Criação dos botões para insirar dentro do grid
            for (int i = 0; i < BOARD_SIZE; i++) {
                for (int j = 0; j < BOARD_SIZE; j++) {
                    buttons[i][j] = new Button();
                    buttons[i][j].setMinSize(800/3, 800/3);
                    buttons[i][j].setOnAction(event -> handleButtonClick(event));
                    buttons[i][j].setFont(Font.font("TimesRoman", FontWeight.BOLD, 125));
                   
                    GridPane.setFillWidth(buttons[i][j], true);
                    GridPane.setFillHeight(buttons[i][j], true);
                    grid.add(buttons[i][j], j, i);
                }
            }
            // Criação de um butão reset
            restartButton = new Button("Restart");
            restartButton.setOnAction(event -> restartGame(event));
    
            restartButton.setVisible(false);
            grid.add(restartButton,0,3);
            // Criação de label 
            playerLabel = new Label("Tic-Tac-Toe");
            playerLabel.setAlignment(Pos.CENTER);
            playerLabel.setFont(Font.font("TimesRoman", FontWeight.BOLD, 75));
            playerLabel.setTextFill(Color.rgb(6, 255, 22));
            
            VBox vbox = new VBox(playerLabel, grid);
            vbox.setAlignment(Pos.CENTER);
            Scene scene = new Scene(vbox);
            primaryStage.setScene(scene);
            primaryStage.show(); 
            firstTurn();
        }
        // metodo para resetar o jogo
        private void restartGame(ActionEvent event) {
            gameOver = false;
            player1Turn = true;
            playerLabel.setText("Tic-Tac-Toe");
            for (int i = 0; i < BOARD_SIZE; i++) {
                for (int j = 0; j < BOARD_SIZE; j++) {
                    buttons[i][j].setText("");
                    buttons[i][j].setDisable(false);
                }
            }
            restartButton.setVisible(false);
            firstTurn();
        }
        // metodo para quando o cpu jogar
            private void playCPU() {
            for(int i = 0; i < BOARD_SIZE; i++) {
                for(int j = 0; j < BOARD_SIZE; j++) {
                    if(buttons[i][j].getText().equals("")) {
                        buttons[i][j].setText("O");
                        buttons[i][j].setDisable(true);
                        checkForWin("O");
                        playerLabel.setText("Player X turn");
                        player1Turn = !player1Turn;
                        return;
                    }
                }
            }
        }
        private void firstTurn() {
            player1Turn = random.nextBoolean();
            if(player1Turn) playerLabel.setText("Player 1 turn");
            else playerLabel.setText("CPU turn");
        }
        // metodo do movimento do cpu
        private void cpuMove() {
            if (!player1Turn && !gameOver) {
                int row = random.nextInt(3);
                int col = random.nextInt(3);
                while (!buttons[row][col].getText().equals("")) {
                    row = random.nextInt(3);
                    col = random.nextInt(3);
                }
                buttons[row][col].setText("O");
                checkForWin("O");
                player1Turn = true;
            }
        }
        // ver se houve alguem que ganhou
        private void checkForWin(String player) {
            if (checkRowsForWin(player) || checkColsForWin(player) || checkDiagonalsForWin(player)) {
                gameOver = true;
                playerLabel.setText(player + " wins!");
                for (int i = 0; i < BOARD_SIZE; i++) {
                    for (int j = 0; j < BOARD_SIZE; j++) {
                        buttons[i][j].setDisable(true);
                    }
                }
                restartButton.setVisible(true);
                } else if (checkForDraw()) {
                gameOver = true;
                playerLabel.setText("It's a draw!");
                for (int i = 0; i < BOARD_SIZE; i++) {
                    for (int j = 0; j < BOARD_SIZE; j++) {
                        buttons[i][j].setDisable(true);
                    }
                }
                restartButton.setVisible(true);
            }
        }
        private boolean checkRowsForWin(String player) {
            for (int i = 0; i < BOARD_SIZE; i++) {
                int count = 0;
                for (int j = 0; j < BOARD_SIZE; j++) {
                    if (buttons[i][j].getText().equals(player)) {
                        count++;
                    }
                }
                if (count == BOARD_SIZE) {
                    return true;
                }
            }
            return false;
        }
        private boolean checkColsForWin(String player) {
            for (int i = 0; i < BOARD_SIZE; i++) {
                int count = 0;
                for (int j = 0; j < BOARD_SIZE; j++) {
                    if (buttons[j][i].getText().equals(player)) {
                        count++;
                    }
                }
                if (count == BOARD_SIZE) {
                    return true;
                }
            }
            return false;
        }
        private boolean checkDiagonalsForWin(String player) {
            int count1 = 0;
            int count2 = 0;
            for (int i = 0; i < BOARD_SIZE; i++) {
                if (buttons[i][i].getText().equals(player)) {
                    count1++;
                }
                if (buttons[i][BOARD_SIZE - 1 - i].getText().equals(player)) {
                    count2++;
                }
            }
            return count1 == BOARD_SIZE || count2 == BOARD_SIZE;
        }
        // evento de click no button
        private void handleButtonClick(ActionEvent event) {
            if (gameOver) {
                return;
            }
            Button button = (Button) event.getSource();
            String buttonText = button.getText();
            if (buttonText.equals("")) {
                if (player1Turn) {
                    button.setText("X");
                    checkForWin("X");
                } else {
                    button.setText("O");
                    checkForWin("O");
                }
                checkForDraw();
                player1Turn = !player1Turn; 
                button.setDisable(true);
                if (!player1Turn) {
                    playCPU();
                }
            }
        }
        // metodo para confirmar se empatou 
        private boolean checkForDraw() {
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                if (buttons[i][j].getText().equals("")) {
                    return false;
                }
            }
        }
        return true;
       }
}