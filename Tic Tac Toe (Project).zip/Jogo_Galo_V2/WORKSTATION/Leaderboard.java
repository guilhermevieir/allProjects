package WORKSTATION;
import java.io.BufferedReader;
import java.io.FileReader;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.List;
import java.util.ArrayList;

public class Leaderboard {
    private Stage stage;
    private Label leaderboardLabel;
    private ListView<String> leaderboardListView;
    private String score1,score2,score3,score4,score5; 
    public Leaderboard(){
        stage = new Stage();
        stage.setTitle("Leaderboard");
        leaderboardLabel = new Label("Leaderboard");
        leaderboardListView = new ListView<>();
    }
    public void start(){
        readScores();
        //Adicionar valores para dentro do listView
        leaderboardListView.getItems().addAll(score1,score2,score3,score4,score5);
        VBox layout = new VBox(10);
        layout.getChildren().addAll(leaderboardLabel, leaderboardListView);
        Scene scene = new Scene(layout, 300, 400);
        stage.setScene(scene);
        stage.hide();
    }
    public void show() {
        stage.show();
    }
    // Leitura de valores
    public void readScores() {
    
    score1 = "Bob - Score: 10";
    score2 = "Mary - Score: 15";
    score3 = "Tom - Score: 20";
     
    }
}