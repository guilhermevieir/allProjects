package WORKSTATION;


import java.util.*;

/** Este template foi criado na 
 * Escola Superior de Tecnologia e Gestão do
 * Instituto Politécnico de Beja
 * em 2021/09/20
 * -----------------------------------------------------
 * Adicione aqui uma descrição da classe, o seu nome e a data
 * @author (o seu nome) 
 * @version (número de versão ou data)
 * 
 * O programa deve ser escrito em inglês.
 */
public class AVISO__user_joao1_pass_1234
{

    // as duas linhas seguintes não devem ser apagadas
    final static Scanner scanner = new Scanner(System.in); // objecto para ler texto
    static { scanner.useLocale(Locale.ENGLISH); } // para garantir que os números reais são lidos com '.' em lugar de ','

    public static void main(String[] args)
    {
        // o texto após // é um comentário e é ignorado pelo computador
        // aqui é onde deve escrever o seu código
        // eis um código de exemplo
        System.out.println("IPB-ESTIG");
        System.out.println();
        //System.out.printf("número inteiro: %d; número real: %f, carácter: %c; " +
        //    "muda de linha %n texto: %s %n %n", 47, 12.33, 'a', "um texto");  
        System.out.print("Indique um número: ");
        int i = scanner.nextInt();
        System.out.println("O seu número é " + i);
    } // END funçtion main
} // END AVISO__user_joao1_pass_1234
