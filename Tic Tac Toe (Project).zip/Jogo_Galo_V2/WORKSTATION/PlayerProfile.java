package WORKSTATION;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;

public class PlayerProfile extends Application {
    String np,npCPU,NpP,Cpuwins,Pwins;
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Player Profile");

        // Criação de um Panel
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        try {
            int n = 0;
            BufferedReader reader = new BufferedReader(new FileReader("joao.txt"));
            String line;
            while((line = reader.readLine()) != null) {
              
                   
                        if(n == 0)
                        {
                        
                        n++;
                            
    
                    }   
                    if(n == 1)
                    {
                     np = line.substring(11);
                     n++;
                    }
                    if(n == 2)
                    {
                     npCPU = line.substring(11);
                        
                        n++;
                    }
                    if(n == 3){
    
                         NpP = line.substring(11);
                    
                        n++;
                    }
                    if(n == 4)
                    {
                        Cpuwins = line.substring(11);
                        
                        n++;
                    }
                    if(n == 5)
                    {
                         Pwins = line.substring(11);
                        
                        n++;
                    }
                }
            }catch(IOException e)
            {
                e.printStackTrace();
            }
        // Criação de labels e insirar valores
        Label nameLabel = new Label("Name:Joao");
        
        Label WinsPlayersLabel = new Label("WinsvsPlayers:" + Pwins);
        Label WinsPlayervsCpu =  new Label("WinsvsCPU:" + Cpuwins);
        grid.add(nameLabel, 0, 0);
    
        grid.add(WinsPlayersLabel, 0, 2);
        grid.add(WinsPlayervsCpu, 0 ,3);

        Scene scene = new Scene(grid, 300, 250);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}