package WORKSTATION;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import javafx.application.Platform;
import javafx.event.ActionEvent;

public class Main extends Application {
    private String[] buttonNames;
    private Leaderboard leaderboard;
    private PlayerProfile PlayerProfile;
    private Stage loginStage;
    private Players p1;
    public void setLoginStage(Stage stage) {
        this.loginStage = stage;
    }
    public Main() {
        this.buttonNames = new String[] {"PlayerVsPlayer", "PlayerVsCPU", "Leaderboard","Perfil" , "Exit"};
        leaderboard = new Leaderboard();
        PlayerProfile = new PlayerProfile();
    }
    @Override
    public void start(Stage primaryStage) {
        leaderboard.start();
        menu(primaryStage);
            if (this.loginStage != null) {
                this.loginStage.close();
        }
    }
    public void menu(Stage primaryStage) {
        //Criação do menu
        primaryStage.setTitle("Menu");
        VBox vb = new VBox(10);
        //Um for para criação dos buttons 
        for (int i = 0; i < buttonNames.length; i++) {
            Button button = new Button(buttonNames[i]);
            button.setMaxSize(300, 300); 
            button.setStyle("-fx-font-size: 2em; "); 
            button.setFont(new Font("TimesRoman", 80)); 
            if (buttonNames[i].equals("PlayerVsPlayer")) {
                button.setOnAction((ActionEvent event) -> {
                Login_Player2 loginp2 = new Login_Player2();
                loginp2.start(new Stage());
                });
            }   
            if (buttonNames[i].equals("PlayerVsCPU")) {
                button.setOnAction((ActionEvent event) -> {
                    TicTacToeCPU gameCPU = new TicTacToeCPU();
                    gameCPU.start(new Stage());
                });
            }
            if (buttonNames[i].equals("Leaderboard")) {
                button.setOnAction((ActionEvent event) -> {
                 leaderboard.show();
                });
            }
            if(buttonNames[i].equals("Perfil"))
            {
                button.setOnAction((ActionEvent event) ->{
                    PlayerProfile.start(new Stage());
                });
                
            }
            if (buttonNames[i].equals("Exit")) {
                button.setOnAction((ActionEvent event) -> {
                    Platform.exit();
                });
            }
            vb.getChildren().add(button);
        }
        //Criação de uma cena
        Scene scene = new Scene(vb, 300, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}