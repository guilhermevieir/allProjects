package WORKSTATION;
import java.io.*;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;    
import javafx.stage.Stage;

public class Register extends Application {
    private TextField usernameField;
    private PasswordField passwordField;
    private Button registerButton;
    private Stage registerStage;
    public static void main(String[] args) {
        launch(args);
    }
    public void setregisterStage(Stage stage) {
        this.registerStage = stage;
    }
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Registration");

        // Criação de um Panel
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        // Criação e adcionar a label do Username dentro do panel
        Label usernameLabel = new Label("Username:");
        grid.add(usernameLabel, 0, 0);

        // Criação de um TextField e adicionar dentro do panel
        usernameField = new TextField();
        grid.add(usernameField, 1, 0);

         // Criação e adcionar a label do Password dentro do panel
        Label passwordLabel = new Label("Password:");
        grid.add(passwordLabel, 0, 1);

        // Criação de um PasswordField e adicionar dentro do panel
        passwordField = new PasswordField();
        grid.add(passwordField, 1, 1);

        // Criação de um Butão e adicionar dentro do panel
        registerButton = new Button("Register");
        grid.add(registerButton, 1, 2);
        registerButton.setOnAction(e -> register(primaryStage));

        Scene scene = new Scene(grid, 300, 275);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    //Criação de metodo do butão para registrar o user e criar o seu ficheiro 
        private void register(Stage primaryStage) {
            String username = usernameField.getText();
            String password = passwordField.getText();
            File file = new File(username + ".txt");
                    if (!file.exists()) {
                        try {
                            file.createNewFile();
                            FileWriter fw = new FileWriter(file);
                            BufferedWriter bw = new BufferedWriter(fw);
                            bw.write("password:"+ password+"\n");
                            bw.write("TOTALGAMES:0"+"\n");
                            bw.write("TOTALGAMESCPU:"+"\n");
                            bw.write("TOTALGAMESHUMAN:0" + "\n");
                            bw.write("TOTALGAMESWINVSCPU:0" + "\n");
                            bw.write("TOTALGAMESWINSVSHUMANS:0" + "\n");
                            bw.close();
                            Alert alert = new Alert(AlertType.INFORMATION);
                            alert.setTitle("Registration Successful");
                            alert.setHeaderText(null);
                            alert.setContentText("Welcome " + username + "!");
                            alert.showAndWait();
                            Login login = new Login();
                            login.start(primaryStage);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Registration Failed");
                alert.setHeaderText(null);
                alert.setContentText("Username already taken. Please choose a different username.");
                alert.showAndWait();
            }
    }
}
