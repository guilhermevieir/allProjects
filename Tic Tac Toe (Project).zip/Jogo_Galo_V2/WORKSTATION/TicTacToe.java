package WORKSTATION;
import javafx.application.*;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.text.FontWeight;
import javafx.scene.layout.Background;
import java.util.Random;
import javafx.scene.layout.BackgroundFill;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.*;

public class TicTacToe extends Application {
    private final int BOARD_SIZE = 3;
    private boolean player1Turn;
    private Button[][] buttons;
    private Label playerLabel;
    private int jogadas = 1;
    Random random = new Random();
     private Players p1;
     private Players p2; 
     private boolean gameOver;
     private String ValueToChange;
    private Button restartButton;
    
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setOnCloseRequest(e -> Platform.runLater(() -> {
            Platform.exit();
            System.exit(0);
        }));
        // Criação do panel grid
        GridPane grid = new GridPane();
        buttons = new Button[BOARD_SIZE][BOARD_SIZE];
        gameOver = false;

        // Criação dos butões e adcionar do panel
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                buttons[i][j] = new Button();
                buttons[i][j].setMinSize(800/3, 800/3);
                buttons[i][j].setOnAction(event -> handleButtonClick(event));
                buttons[i][j].setFont(Font.font("TimesRoman", FontWeight.BOLD, 125));
                //textfield.setFont(Font.font("TimesRoman", FontWeight.BOLD, 75));
                GridPane.setFillWidth(buttons[i][j], true);
                GridPane.setFillHeight(buttons[i][j], true);
                grid.add(buttons[i][j], j, i);
            }
        }
        // Criação de um botão para dar reset
        restartButton = new Button("Restart");
        restartButton.setOnAction(event -> restartGame(event));

        restartButton.setVisible(false);
        grid.add(restartButton,0,3);
        
        playerLabel = new Label("Tic-Tac-Toe");
        playerLabel.setAlignment(Pos.CENTER);
        playerLabel.setFont(Font.font("TimesRoman", FontWeight.BOLD, 75));
        playerLabel.setTextFill(Color.rgb(6, 255, 22));

        
        VBox vbox = new VBox(playerLabel, grid);
        vbox.setAlignment(Pos.CENTER);
        Scene scene = new Scene(vbox);
        primaryStage.setScene(scene);
        primaryStage.show(); 
        
        firstTurn();
    }
        private void restartGame(ActionEvent event) {
        gameOver = false;
        player1Turn = true;
        playerLabel.setText("Tic-Tac-Toe");
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                buttons[i][j].setText("");
                buttons[i][j].setDisable(false);
            }
        }
        restartButton.setVisible(false);
    }
    // metodo para confimar se ja acabou 
    private void checkForWinner() {
        String text1 = "", text2 = "", text3 = "";
    
        for (int i = 0; i < BOARD_SIZE; i++) {
            text1 = buttons[i][0].getText();
            text2 = buttons[i][1].getText();
            text3 = buttons[i][2].getText();
            if (!text1.isEmpty() && text1.equals(text2) && text2.equals(text3)) {
                gameOver = true;
                if (text1.equals("X")) {
                    playerLabel.setText("Player1 Ganhou!");
                    playerLabel.setTextFill(Color.rgb(255,0 ,0));
                    writefileplayer1();
                } else {
                    playerLabel.setText("Player 2 ganhou!");
                    playerLabel.setTextFill(Color.BLUE);
                }
                disableButtons();
                
            }
        }
        
        for (int i = 0; i < BOARD_SIZE; i++) {
            text1 = buttons[0][i].getText();
            text2 = buttons[1][i].getText();
            text3 = buttons[2][i].getText();
            if (!text1.isEmpty() && text1.equals(text2) && text2.equals(text3)) {
                gameOver = true;
                if (text1.equals("X")) {
                    playerLabel.setText("Player 1 Ganhou!");
                    playerLabel.setTextFill(Color.rgb(255,0 ,0));
                    writefileplayer1();
                } else {
                    playerLabel.setText("Player 2 ganhou!");
                    playerLabel.setTextFill(Color.BLUE);
                }
                disableButtons();
                return;
            }
        }
        
        text1 = buttons[0][0].getText();
        text2 = buttons[1][1].getText();
        text3 = buttons[2][2].getText();
        if (!text1.isEmpty() && text1.equals(text2) && text2.equals(text3)) {
            gameOver = true;
            if (text1.equals("X")) {
                playerLabel.setText("Player 1 Ganhou!");
                playerLabel.setTextFill(Color.RED);
            } else {
                playerLabel.setText("Player 2 ganhou!");
                playerLabel.setTextFill(Color.BLUE);
            }
            disableButtons();
            return;
        }
        text1 = buttons[0][2].getText();
        text2 = buttons[1][1].getText();
        text3 = buttons[2][0].getText();
        if (!text1.isEmpty() && text1.equals(text2) && text2.equals(text3)) {
            gameOver = true;
            if (text1.equals("X")) {
                playerLabel.setText("Player 1 ganhou!");
                playerLabel.setTextFill(Color.RED);
                
            } else {
                playerLabel.setText("Player 2 ganhou!");
                playerLabel.setTextFill(Color.BLUE);
            }
            disableButtons();
            return;
        }
        // Confirmar se empatou
        if (jogadas == BOARD_SIZE * BOARD_SIZE) {
            playerLabel.setText("Empate!");
            gameOver = true;
            disableButtons();
            
        }
        jogadas++;
    }
        private void handleButtonClick(ActionEvent event) {
        Button button = (Button) event.getSource();
        if (!gameOver) {
            if (button.getText().isEmpty()) {
            if (player1Turn) {
                playerLabel.setText("Player 1");
                playerLabel.setTextFill(Color.RED);
                button.setText("X");
                button.setTextFill(Color.RED);
                
            } else {
                playerLabel.setText("Player 2");
                playerLabel.setTextFill(Color.BLUE);
                button.setText("O");
                button.setTextFill(Color.BLUE);
               
            }
            button.setDisable(true);
            checkForWinner();
            player1Turn = !player1Turn;//
            }
        }
    }
    private void firstTurn() {
        int randomNumber = random.nextInt(2);
        if (randomNumber == 0) {
            player1Turn = true;
            playerLabel.setText("Player 1");
            playerLabel.setTextFill(Color.RED);
        } else {
            player1Turn = false;
            playerLabel.setText("Player2");
            playerLabel.setTextFill(Color.BLUE);
        }
        }
    private boolean checkForWin() {
     
            for (int i = 0; i < BOARD_SIZE; i++) {
                if (checkRowCol(buttons[i][0].getText(), buttons[i][1].getText(), buttons[i][2].getText())) {
                    gameOver = true;
                    disableButtons();
                    return true;
                }
            }
            
            for (int i = 0; i < BOARD_SIZE; i++) {
                if (checkRowCol(buttons[0][i].getText(), buttons[1][i].getText(), buttons[2][i].getText())) {
                    gameOver = true;
                    disableButtons();
                    return true;
                }
            }
           
            if (checkRowCol(buttons[0][0].getText(), buttons[1][1].getText(), buttons[2][2].getText()) || 
                checkRowCol(buttons[0][2].getText(), buttons[1][1].getText(), buttons[2][0].getText())) {
                    gameOver = true;
                    disableButtons();
                    return true;
            }
            return false;
        }
    private boolean checkRowCol(String s1, String s2, String s3) {
        return !s1.isEmpty() && s1.equals(s2) && s2.equals(s3);
    }
    private void reset() {
        gameOver = false;
        player1Turn = true;
        playerLabel.setText("Tic-Tac-Toe");
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                buttons[i][j].setText("");
                buttons[i][j].setDisable(false);
            }
        }
        restartButton.setVisible(false);
    }
    public void handleResetButtonClick(ActionEvent event) {
        reset();
        gameOver = false;
    }
    public void disableButtons() {
        for(int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                buttons[i][j].setDisable(true);
            }
        }
    }
    public void writefileplayer1()
    {
         try {
            File file = new File(p1.getName() + ".txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            int lineNumber = 6;
            int currentLine = 0;
            StringBuilder newLine  = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                if (currentLine == lineNumber) {
                    int currentwins = p1.GetWinsPlayer() + 1;
                    newLine.append(line.replace(Integer.toString(p1.GetWinsPlayer()),Integer.toString(currentwins))).append("\n");
                } else {
                    newLine.append(line).append("\n");
                }
                currentLine++;
            }

            reader.close();
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(newLine.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
