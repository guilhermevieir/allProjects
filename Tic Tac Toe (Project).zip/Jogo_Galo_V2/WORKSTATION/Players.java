package WORKSTATION;
public class Players
{
       String Name;
       int np, wins ,totalgames, Cpuwins , Pwins, NpCpu  ,NpP ; 
       public Players(String Name)
       {
           this.Name = Name;
           this.wins = 0;
           this.totalgames = 0;
           this.Cpuwins = 0;
           this.Pwins = 0;
           this.NpCpu = 0;
           this.NpP = 0;
           
       }
    public void setName(String Name)
    {
        this.Name = Name;
    }
    public void setnp(int np)
    {
        this.np = np;
    }
    public void SetNpCPU(int NpCpu)
    {
        this.NpCpu = NpCpu;
    }
    public int GetNpCPU()
    {
        return this.NpCpu;
    }
    public void SetNpP(int NpP)
    {
        this.NpP = NpP;
    }
    public int GetNpP()
    {
        return this.NpP;
    }
    public String getName()
    {
        return Name;
    }
    public Integer getnp()
    {
        return this.np;
    }
    public void setWins(int wins)
    {
        this.wins = wins;
    }
    public int getWins()
    {
        wins = this.Cpuwins + this.Pwins;
        return this.wins;
    }
    public void SetTotalgames(int totalgames)
    {
        this.totalgames = totalgames;
    }
    public int GetTotalgames()
    {
        return this.totalgames;
    }
    public void SetWinsCPU(int Cpuwins)
    {
        this.Cpuwins = Cpuwins;
    }
    public int GetWinsCPU()
    {
        return this.Cpuwins;
    }
    public void SetWinsPlayer(int Pwins)
    {
        this.Pwins = Pwins;
    }
    public int GetWinsPlayer()
    {
        return this.Pwins;
    }

}