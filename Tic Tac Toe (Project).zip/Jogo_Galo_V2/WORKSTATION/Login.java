package WORKSTATION;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class Login extends Application {
   private Players p1;
   private Button registerButton;
    public static void main(String[] args) {
        launch(args);
    }
    private Stage primaryStage;
    // Criação de um textfield global
    TextField userTextField = new TextField();
    // Criação de uma Password textfield (textfield mas com os caracteres escondidos)
    PasswordField pwBox = new PasswordField();

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Login Page");

        // Criar um panel Grid 
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        // Criar um Label para ser usado dentro do panel
        Label userName = new Label("Username:");
        grid.add(userName, 0, 0);

        // Adcionar o textfield para dentro do panel
        grid.add(userTextField, 1, 0);

        // Add a label for the password
        Label pw = new Label("Password:");
        grid.add(pw, 0, 1);

       // Adicionar o passwordfield ao grid
        grid.add(pwBox, 1, 1);

        // Criar um botão e adicionar ao panel
        Button loginButton = new Button("Login");
        grid.add(loginButton, 0, 2);
        
                loginButton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                buttonClick(event);
            }
            });
            // Criação de um butão registro com objetivo de entrar no panel Register
    registerButton = new Button("Register");
    grid.add(registerButton, 1, 2);
        
    registerButton.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        registerClick(event);
    }
    });
        Scene scene = new Scene(grid, 300, 275);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    // Metodo de click do butão de registro
    private void registerClick(ActionEvent event) {
    String nome;
    nome = userTextField.getText();
    p1 = new Players(nome);
        
    Register main = new Register();
    Register register = new Register();
    register.start(new Stage());
    }
    // Metodo de click do butão de login
    private void buttonClick(ActionEvent event) {
    String nome;
    nome = userTextField.getText();
    p1 = new Players(nome);
    try {
        int n = 0;
        BufferedReader reader = new BufferedReader(new FileReader(nome +".txt"));
        String line;
        while((line = reader.readLine()) != null) {
                String result = line.substring(9);
                if (result.equals(pwBox.getText())) {
                    if(n == 0)
                    {
                    
                    Main main = new Main();
                    main.setLoginStage(this.primaryStage);
                    main.start(new Stage());
                    p1.setName(nome);
                    n++;
                    Alert alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Login Sucefull");
                    alert.setHeaderText(null);
                    alert.setContentText("Welcome to TicTacToe ");
                    alert.showAndWait();
                }   
                if(n == 1)
                {
                 String np = line.substring(11);
                 p1.setnp(Integer.parseInt(np));
                 n++;
                }
                if(n == 2)
                {
                    String npCPU = line.substring(14);
                    p1.SetNpCPU(Integer.parseInt(npCPU));
                    n++;
                }
                if(n == 3)
                {
                    String NpP = line.substring(16);
                    p1.SetNpP(Integer.parseInt(NpP));
                    n++;
                }
                if(n == 4)
                {
                    String Cpuwins = line.substring(19);
                    p1.SetWinsCPU(Integer.parseInt(Cpuwins));
                    n++;
                }
                if(n == 5)
                {
                    String Pwins = line.substring(23);
                    p1.setWins(Integer.parseInt(Pwins));
                    n++;
                }
                } else {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Authetic Error");
                alert.setHeaderText("Login fail");
                alert.setContentText("Wrong Password or Username");
                alert.showAndWait();
                    reader.close();
                }
            }
            reader.close();
            // Check if the entered username and password match the credentials
         }catch 
         (IOException e) {
            e.printStackTrace();
        }  
    }
}